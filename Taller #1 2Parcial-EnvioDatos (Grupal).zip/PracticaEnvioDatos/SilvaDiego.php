<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
    <title>Metodos de envio de datos</title>
    <meta name="author" content="Silva Diego y Bagua Leidy">

    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            border: 1px solid #ccc;
            padding: 20px;
            width: 400px;
            margin-left: auto; 
            margin-right: auto;
            box-sizing: border-box;
            box-sizing: border-box;
        }

        .error {
        color: red;
        }

        form label {
        font-weight: normal;
        }

        form label[for="titulo"] {
        text-transform: uppercase;
        font-size: 1.1em;
        font-weight: bold;
        }
    </style>
</head>

<body>
    <?php
        require_once "Funcion.php";

        $nombreError = $correoError = $EstiloCocinaError = $TipoDepaError = "";
        $nombre = $correo = $EstiloCocina = $TipoDepa = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST['nombre'])) {
                $nombreError = "Nombre es requerido";
            } else {
                $nombre = clear_input($_POST['nombre']);
            }

            $correo = isset($_POST['correo']) ? clear_input($_POST['correo']) : "";

            if (empty($_POST['EstiloCocina'])) {
                $EstiloCocinaError = "Estilo de cocina requerido";
            } else {
                $EstiloCocina = clear_input($_POST['EstiloCocina']);
            }

            if (empty($_POST['TipoDepa'])) {
                $TipoDepaError = "Seleccion de departamento requerida";
            } else {
                $TipoDepa = clear_input($_POST['TipoDepa']);
            }
        }
    ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="titulo">Cotizador de Departamento</label>
        </br></br>
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre">
        <span class="error">* <?php echo $nombreError; ?></span>
        </br></br>
        <label for="correo">Correo:</label>
        <input type="text" name="correo">
        </br></br>
        <label for="TipoDepa">Tipo De Departamento:</label>
        <select name="TipoDepa">
            <option value="0">Seleccione...</option>
            <option value="Suite">Suite</option>
            <option value="Dos_Habitaciones">Dos Habitaciones</option>
            <option value="Tres_Habitaciones">Tres Habitaciones</option>
        </select>
        <span class="error">* <?php echo $TipoDepaError; ?></span>
        </br></br>
        <label for="EstiloCocina">Estilo de Cocina:</label>
        <input type="radio" name="EstiloCocina" value="A">Americana
        <input type="radio" name="EstiloCocina" value="I">Isla
        <span class="error">* <?php echo $EstiloCocinaError; ?></span>
        <p><b>Servicios Adicionales<b></p>
        <div>
            <label><input type="checkbox" id="cbox1" name="valorAdicional[]" value="Gimnasio" />Gimnasio</label>
            </br></br>
            <label><input type="checkbox" id="cbox2" name="valorAdicional[]" value="coworking" />Area de coworking</label>
            </br></br>
            <label><input type="checkbox" id="cbox3" name="valorAdicional[]" value="SPA" />SPA</label>
            </br></br>
        </div>
        <input type="submit" value="Enviar">
        <input type="reset" value="Reset">
    </form>

    <?php
        $precio_base = 0;
        $alicuota = 50;

        if (!empty($nombre) && !empty($EstiloCocina) && !empty($TipoDepa)) {
            echo "<h4>Tus datos:</h4>";
            echo "<p>Nombre: {$nombre}</p>";
            echo "<p>Correo: {$correo}</p>";

            if ($EstiloCocina == 'I') {
                $precio_base += 574;
                echo "<p>Estilo de cocina: Isla</p>";
            } else {
                $precio_base += 849;
                echo "<p>Estilo de cocina: Americana</p>";
            }

            echo "<p>Tipo de Departamento: {$TipoDepa}</p>";

            switch ($TipoDepa) {
                case "Suite":
                    $precio_base += 90000;
                    break;
                case "Dos_Habitaciones":
                    $precio_base += 100000;
                    break;
                case "Tres_Habitaciones":
                    $precio_base += 120000;
                    break;
                default:
                    break;
            }

            if (isset($_POST["valorAdicional"])) {
                $numServicios = count($_POST["valorAdicional"]);
                $alicuota += $numServicios * 60;
            }

            echo "Servicios adicionales: " . implode(", ", $_POST["valorAdicional"]) . "\n";
            echo "Valor de cotización del departamento: $precio_base\n";
            echo "Valor de alícuota calculado: $alicuota\n";
        }
    ?>

</body>
</html>