<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Silva Muñoz Diego">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Curso</title>
</head>
<body>

<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $cursoId = $_POST['id'];
    $nombreCurso = $_POST['nombre_curso'];
    $promocion = $_POST['promocion'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];

    // Evitar inyección de SQL usando sentencias preparadas
    $stmt = $conn->prepare("UPDATE cursos SET nombre_curso = ?, promocion = ?, descripcion = ?, precio = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $nombreCurso, $promocion, $descripcion, $precio, $cursoId);

    if ($stmt->execute()) {
        echo "Curso actualizado correctamente.";
    } else {
        echo "Error al actualizar el curso: " . $conn->error;
    }

    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $cursoId = $_GET['id'];

        // Obtener datos del curso a editar
        $stmt = $conn->prepare("SELECT * FROM cursos WHERE id = ?");
        $stmt->bind_param("i", $cursoId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result === false) {
            echo "Error en la consulta: " . $conn->error;
        } else {
            // Verificar si se obtuvieron resultados
            if ($result->num_rows > 0) {
                $curso = $result->fetch_assoc();

                // Mostrar formulario de edición
                ?>
                <h2>Editar Curso</h2>
                <form method="POST" action="">
                    <input type="hidden" name="id" value="<?= $curso['id'] ?>">
                    <label for="nombre_curso">Nombre del Curso:</label>
                    <input type="text" id="nombre_curso" name="nombre_curso" value="<?= $curso['nombre_curso'] ?>"><br>

                    <label for="promocion">Promoción:</label>
                    <input type="text" id="promocion" name="promocion" value="<?= $curso['promocion'] ?>"><br>

                    <label for="descripcion">Descripción:</label>
                    <textarea id="descripcion" name="descripcion"><?= $curso['descripcion'] ?></textarea><br>

                    <label for="precio">Precio:</label>
                    <input type="text" id="precio" name="precio" value="<?= $curso['precio'] ?>"><br>

                    <input type="submit" value="Guardar cambios">
                </form>
                <?php
            } else {
                echo "Curso no encontrado.";
            }
        }

        $stmt->close();
    } else {
        echo "Parámetros incorrectos. ID no proporcionado o no es numérico.";
    }
} else {
    echo "Parámetros incorrectos. Método de solicitud no válido.";
}

// Cerrar conexión
$conn->close();
?>

</body>
</html>

