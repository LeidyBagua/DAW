<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Bagua Sinaluisa, Leidy">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas</title>

    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        #container {
            max-width: 800px;
            width: 100%;
            max-height: 500px;
            overflow-y: auto;
            padding: 20px;
            box-sizing: border-box;
        }

        h2 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<div id="container">

<?php
    include 'conexion.php';

    function obtenerConsultaCursos($conn) {
        $sql = "SELECT * FROM cursos";

        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $searchTerm = $_GET['search'];
            $sql .= " WHERE nombre_curso LIKE '%$searchTerm%'";
        }

        return $conn->query($sql);
    }

    function mostrarResultadosTabla($result) {
        if ($result->num_rows > 0) {
            echo "<table border='1'>";
            echo "<tr><th>ID</th><th>Nombre del Curso</th><th>Promoción</th><th>Descripción</th><th>Precio</th><th>Opciones</th></tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . (isset($row['id']) ? $row['id'] : 'N/A') . "</td>";
                echo "<td>" . (isset($row['nombre_curso']) ? $row['nombre_curso'] : 'N/A') . "</td>";
                echo "<td>" . (isset($row['promocion']) ? $row['promocion'] : 'N/A') . "</td>";
                echo "<td>" . (isset($row['descripcion']) ? $row['descripcion'] : 'N/A') . "</td>";
                echo "<td>" . (isset($row['precio']) ? $row['precio'] : 'N/A') . "</td>";
                echo "<td><a href='editar.php?id=" . (isset($row['id']) ? $row['id'] : '') . "'>Editar</a> | <a href='eliminar.php?id=" . (isset($row['id']) ? $row['id'] : '') . "'>Eliminar</a></td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "No hay cursos disponibles.";
        }
    }

    // Obtener resultados de la consulta
    $result = obtenerConsultaCursos($conn);
    ?>

    <h2>Cursos de Programación</h2>

    <!-- Agregar formulario de búsqueda -->
    <form method="GET" style="text-align: center; margin-bottom: 10px;">
        <label for="search">Buscar por nombre:</label>
        <input type="text" id="search" name="search" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <input type="submit" value="Buscar">
    </form>

     <!-- Agregar botón "Insertar" -->
     <div style="text-align: right; margin-top: 10px;">
        <a href="insertar.php"><button>Insertar nuevo curso</button></a>
    </div>

    <?php
    // Mostrar resultados en la tabla
    mostrarResultadosTabla($result);

    // Cerrar conexión
    $conn->close();
    ?>

</div>

</body>
</html>