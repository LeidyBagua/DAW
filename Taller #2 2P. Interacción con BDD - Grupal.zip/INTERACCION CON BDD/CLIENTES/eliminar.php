<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Silva Muñoz Diego">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Curso</title>

    </head>
<body>
<?php
include 'conexion.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Utilizar una sentencia preparada para evitar la inyección SQL
    $sql = "DELETE FROM cursos WHERE id_AUTO_INCREMENT = ?";
    
    // Preparar la sentencia
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        // Error al preparar la sentencia
        die("Error al preparar la sentencia: " . $conn->error);
    }
    
    // Vincular el parámetro
    $stmt->bind_param('i', $id);

    // Mostrar confirmación en JavaScript
    echo '<script>';
    echo 'if(confirm("¿Estás seguro de eliminar el campo?")) {';
    echo '  var result = ' . $stmt->execute() . ';';
    echo '  if (result) {';
    echo '    alert("Registro eliminado correctamente");';
    echo '    window.location.href = "consultar.php";';
    echo '  } else {';
    echo '    alert("Error al eliminar el registro: ' . $stmt->error . '");';
    echo '  }';
    echo '} else {';
    echo '  window.location.href = "consultar.php";';
    echo '}';
    echo '</script>';

    // Cerrar la sentencia preparada
    $stmt->close();
} else {
    echo "ID no proporcionado para eliminar";
}

// Cerrar la conexión
$conn->close();
?>

</body>
</html>