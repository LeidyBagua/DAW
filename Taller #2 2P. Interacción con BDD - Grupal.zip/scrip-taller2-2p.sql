-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-12-2023 a las 04:23:10
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `scrip-taller2-2p`
--
DROP DATABASE IF EXISTS `scrip-taller2-2p`;
CREATE DATABASE IF NOT EXISTS `scrip-taller2-2p` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `scrip-taller2-2p`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE `cursos` (
  `id_AUTO_INCREMENT` int(11) NOT NULL,
  `nombre_curso` varchar(50) NOT NULL,
  `promocion` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cursos`
--

INSERT INTO `cursos` (`id_AUTO_INCREMENT`, `nombre_curso`, `promocion`, `descripcion`, `precio`) VALUES
(1, 'Cursos de Python (2023)', 'Rebajas del 30% por navidad', 'Cursos de Python\r\nTres niveles:\r\n1. Basico\r\n2. Intermedio\r\n3. Avanzado', 98.00),
(2, 'Cursos de JavaScript (2023)', 'Rebajas del 30% por navidad', 'Cursos basicos de Javascript\r\nIncluye:\r\n1. Clases en vivo.\r\n2. Herramientas de trabajo.\r\n3. Certificado.\r\n', 104.00),
(3, 'Curso de Desarrollo Web Completo', ' ¡Inscríbete ahora y obtén acceso gratuito a mater', 'Aprende desde lo básico hasta las tecnologías más avanzadas para convertirte en un desarrollador web completo.', 49.00),
(4, 'Curso de Desarrollo de Aplicaciones Móviles (iOS y', '¡Inscríbete ahora y recibe un descuento del 20% en', 'Conviértete en un desarrollador de aplicaciones móviles y crea apps para iOS y Android.', 69.00),
(5, 'Curso de Ciberseguridad y Ethical Hacking', ' ¡Certificación de hacking ético incluida al compl', 'Conviértete en un experto en ciberseguridad y aprende prácticas éticas de hacking.', 99.99),
(6, 'Curso de Git y GitHub', '¡Participa en sesiones en vivo para resolver dudas', 'Domina el control de versiones y colaboración en equipo con Git y GitHub.', 19.99),
(7, 'Curso Avanzado de Machine Learning', '\"MLPro100\"', 'Profundiza en algoritmos de aprendizaje automático, modelado predictivo y redes neuronales.', 199.00);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id_AUTO_INCREMENT`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id_AUTO_INCREMENT` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
