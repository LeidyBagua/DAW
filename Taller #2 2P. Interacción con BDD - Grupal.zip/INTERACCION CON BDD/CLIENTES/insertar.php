<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Bagua Sinaluisa, Leidy">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertar</title>

    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        #container {
            max-width: 800px;
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
            text-align: center;
        }

        h2 {
            text-align: center;
            margin: 0 0 20px;
        }

        form {
            
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input,
        textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            cursor: pointer;
        }
    </style>

</head>
<body>

    <?php
    include 'conexion.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombreCurso = $_POST['nombre_curso'];
        $promocion = $_POST['promocion'];
        $descripcion = $_POST['descripcion'];
        $precio = $_POST['precio'];

        // Insertar datos en la base de datos
        $sql = "INSERT INTO cursos (nombre_curso, promocion, descripcion, precio) VALUES ('$nombreCurso', '$promocion', '$descripcion', '$precio')";

        if ($conn->query($sql) === TRUE) {
            // Redirigir a consultar.php después de la inserción
            header("Location: consultar.php");
            exit();
        } else {
            echo "Error al insertar el curso: " . $conn->error;
        }
    }
    
    $conn->close();
    ?>


<div id="container">

<h2>Insertar Nuevo Curso</h2>

<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="nombre_curso">Nombre del Curso:</label>
    <input type="text" id="nombre_curso" name="nombre_curso" required>

    <label for="promocion">Promoción:</label>
    <input type="text" id="promocion" name="promocion">

    <label for="descripcion">Descripción:</label>
    <textarea id="descripcion" name="descripcion"></textarea>

    <label for="precio">Precio:</label>
    <input type="number" id="precio" name="precio" step="0.01" required>

    <input type="submit" value="Insertar Curso">
</form>

</div>
</body>
</html>